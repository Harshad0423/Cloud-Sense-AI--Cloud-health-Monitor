# CloudSense AI — Intelligent Cloud Storage Health Advisor

**Live AWS version.** Uploads, file metadata, deletion, recommendations,
dashboard statistics, analytics, reports, and user settings are connected to
the CloudSense backend in AWS.

---

## 1. What is CloudSense AI?

CloudSense AI is a cloud-storage monitoring dashboard. It is designed to:

- Give your cloud storage a **Cloud Health Score** out of 100
- Detect **duplicate files** and **inactive files**
- Flag **large files** that could be compressed or archived
- Turn all of that into **prioritized cleanup recommendations**
- Summarize everything into a **weekly report**

Uploaded files are stored in Amazon S3. File metadata and preferences are stored
in DynamoDB and exposed to the frontend through API Gateway and Lambda.

---

## 2. Project structure

```text
CloudSense-AI/
│
├── frontend/
│   ├── index.html              # Landing page / project overview
│   ├── dashboard.html          # Main dashboard (health score, metrics, storage)
│   ├── files.html              # File table, search/filter/sort, upload, duplicates
│   ├── recommendations.html    # Prioritized recommendation cards
│   ├── website-similarity.html # URL-to-URL concept/content/code/design analysis
│   ├── analytics.html          # Health-score breakdown + storage/health charts
│   ├── reports.html            # Weekly report + simulated "Generate Report"
│   ├── settings.html           # Account, analysis frequency, notification toggles
│   │
│   ├── css/
│   │   ├── style.css           # Design tokens + all component styles
│   │   └── responsive.css      # Mobile / tablet breakpoints
│   │
│   ├── js/
│   │   ├── app.js              # Shared shell: sidebar, topbar, toasts, modals,
│   │   │                       #   and the future-facing `api.*` functions
│   │   ├── mockData.js         # All mock/demo data lives here
│   │   ├── dashboard.js        # Dashboard page logic
│   │   ├── files.js            # Files page logic (table, upload, duplicates)
│   │   ├── recommendations.js  # Recommendations page logic
│   │   ├── website-similarity.js # Website comparison page logic
│   │   ├── analytics.js        # Analytics / health-score breakdown logic
│   │   ├── reports.js          # Reports page logic
│   │   └── settings.js         # Settings page logic
│   │
│   └── assets/                 # (empty — reserved for icons/images)
│
├── backend/
│   └── website_similarity/     # Secure, dependency-free comparison Lambda
│
└── README.md
```

---

## 3. How to run it locally

No build step or `npm install` is required. The configured AWS API must remain
available for live data features.

**Option A — VS Code Live Server (recommended)**
1. Open the `CloudSense-AI` folder in VS Code.
2. Install the **Live Server** extension (by Ritwick Dey) if you don't have it.
3. Right-click `frontend/index.html` → **Open with Live Server**.
4. Your browser opens at something like `http://127.0.0.1:5500/frontend/index.html`.

**Option B — Any static file server**
```bash
cd CloudSense-AI/frontend
python3 -m http.server 5500
# then open http://localhost:5500 in your browser
```

**Option C — Just open the file**
You can also open `frontend/index.html` directly in a browser by
double-clicking it. Everything will still work since there are no
server-side dependencies.

---

## 4. Current features

- **Dashboard** — Cloud Health Score ring, storage used, duplicate/inactive/large
  file counts, potential savings, and a storage-by-category breakdown.
- **Files** — searchable, filterable, sortable file table with pagination,
  a drag-and-drop upload zone with real AWS upload progress, and a
  duplicate-file review modal.
- **Recommendations** — priority-ranked cards (High / Optimization / Storage
  Optimization) with a "Take Action" flow and confirmation dialogs.
- **Website Check** — compares two public URLs across concept, visible content,
  HTML structure, and design markers. A shared concept is shown separately and
  does not increase the duplication score.
- **Analytics** — live health-score and storage-category analysis.
- **Reports** — a generated weekly report you can download as a `.txt` file.
- **Settings** — account info, analysis frequency, and notification toggles
  persisted in the `CloudSense-Settings` DynamoDB table.
- Responsive layout with a collapsible mobile sidebar, toast notifications,
  confirmation dialogs, loading/empty states, and keyboard-accessible
  focus states throughout.

---

## 5. Data architecture

Pages call functions on the `api` object defined in `frontend/js/app.js`, for
example:

```javascript
const files = await api.getFiles();
```

The API layer calls API Gateway endpoints and converts the backend payloads into
the shapes required by each page. `mockData.js` remains only for small UI
fallbacks such as the notification dropdown and load-error defaults.

---

## 6. AWS integration

**Current data flow:**

```text
Frontend  →  API Gateway  →  Lambda  →  S3 / DynamoDB
```

AWS services and their role:

| Service        | Role                                              |
|----------------|----------------------------------------------------|
| Amazon S3      | Stores the actual uploaded files                   |
| AWS Lambda     | Backend processing (dedupe hashing, scoring, etc.) |
| API Gateway    | Exposes Lambda functions as HTTP endpoints         |
| DynamoDB       | Stores file metadata, health scores, settings      |
| EventBridge    | Runs the weekly storage report automatically        |
| SNS            | Delivers the weekly storage report by email         |
| CloudWatch     | Monitoring and alarms                              |
| IAM            | Access control between services                    |

Uploaded-file duplicate detection uses a streamed SHA-256 content hash. Large
files are flagged at 5 MB and inactive files are detected after 90 days.

Website comparison is intentionally separate from file deduplication. Its
duplication score weights visible content (45%), HTML/class structure (35%),
and available design markers (20%). Concept similarity is reported separately
so competing businesses are not treated as duplicates solely for sharing an
idea. The result is an indicator for human review, not a legal determination.

No AWS credentials, API keys, or secrets exist anywhere in this frontend
codebase — and none should ever be added directly to it;
authenticated calls should go through API Gateway with proper IAM
permissions on the backend.

### Current API endpoints

The base URL is `https://93mhrfioe1.execute-api.ap-south-1.amazonaws.com`.

- `POST /upload-url`
- `GET /files`
- `DELETE /files/{fileId}`
- `GET /recommendations`
- `GET /dashboard-stats`
- `GET /settings`
- `PUT /settings`
- `POST /website-similarity`

The upload endpoint returns a presigned S3 URL. API Gateway and the S3 bucket
must both allow the frontend origin through their CORS settings.
