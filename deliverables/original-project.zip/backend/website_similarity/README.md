# CloudSense Website Similarity Lambda

Create a Python 3.12 Lambda named `CloudSense-WebsiteSimilarity` and replace its
`lambda_function.py` with the file in this directory. It uses only Python's
standard library, so it does not need a Lambda layer.

Recommended Lambda configuration:

- Memory: 256 MB
- Timeout: 30 seconds
- Architecture: x86_64
- Execution role: basic CloudWatch Logs permissions only
- Do not attach the function to a VPC, because it must fetch public webpages

Create an HTTP API route:

```text
POST /website-similarity
```

Attach it to the Lambda integration and ensure API Gateway CORS allows `POST`
and the `content-type` header.

The test event compares `example.com` and `example.org`, two intentionally
similar demonstration pages. Some production websites block automated requests;
the Lambda returns a clear 422 response when that occurs.

Security controls included in the function:

- Only HTTP and HTTPS URLs on their standard ports
- DNS resolution and rejection of private, loopback, link-local, reserved, or
  otherwise non-public IP addresses
- Redirect validation
- 1.25 MB response limit and 10-second fetch timeout
- HTML-only analysis

The result is a similarity indicator for human review, not a legal plagiarism
or copyright determination.
