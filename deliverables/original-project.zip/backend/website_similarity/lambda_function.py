"""CloudSense Website Similarity Lambda.

Accepts two public URLs and compares four independent signals:
concept/category, visible content, HTML structure, and design markers.
The duplication score intentionally excludes concept similarity so two
businesses in the same category are not labelled as clones merely because
they solve the same problem.

This implementation uses only the Python standard library and is suitable for
the AWS Lambda Python 3.12 runtime.
"""

import json
import ipaddress
import math
import re
import socket
from collections import Counter
from difflib import SequenceMatcher
from html.parser import HTMLParser
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlsplit, urlunsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener


MAX_RESPONSE_BYTES = 1_250_000
FETCH_TIMEOUT_SECONDS = 10
MAX_TEXT_WORDS = 12_000
MAX_STRUCTURE_TAGS = 6_000

USER_AGENT = (
    "Mozilla/5.0 (compatible; CloudSenseSimilarity/1.0; "
    "+https://example.invalid/cloudsense)"
)

STOP_WORDS = {
    "a", "an", "and", "are", "as", "at", "be", "been", "but", "by", "can",
    "do", "for", "from", "had", "has", "have", "he", "her", "here", "his",
    "how", "i", "if", "in", "into", "is", "it", "its", "more", "not", "of",
    "on", "or", "our", "out", "she", "so", "than", "that", "the", "their",
    "them", "then", "there", "they", "this", "to", "up", "us", "was", "we",
    "were", "what", "when", "where", "which", "who", "will", "with", "you",
    "your", "www", "com", "home", "menu", "click", "read", "learn", "get",
}

CATEGORY_KEYWORDS = {
    "Food delivery": {
        "food delivery", "restaurant", "restaurants", "order food", "dining",
        "cuisine", "meal", "meals", "grocery delivery", "menu",
    },
    "E-commerce": {
        "shop online", "shopping", "product", "products", "cart", "checkout",
        "buy online", "marketplace", "free shipping", "add to cart",
    },
    "Education": {
        "course", "courses", "learn", "learning", "student", "students",
        "education", "tutorial", "training", "classroom", "university",
    },
    "Travel": {
        "travel", "hotel", "hotels", "flight", "flights", "booking", "trip",
        "destination", "holiday", "vacation", "tour",
    },
    "Finance": {
        "banking", "bank", "finance", "financial", "investment", "investing",
        "loan", "loans", "insurance", "credit", "payment", "payments",
    },
    "Healthcare": {
        "health", "healthcare", "doctor", "doctors", "hospital", "medical",
        "medicine", "patient", "patients", "clinic", "appointment",
    },
    "News and media": {
        "breaking news", "latest news", "journalism", "article", "articles",
        "headlines", "politics", "world news", "newspaper",
    },
    "Social network": {
        "social network", "community", "followers", "profile", "connect",
        "messages", "friends", "share photos", "social media",
    },
    "Cloud and software": {
        "cloud", "software", "platform", "developer", "developers", "api",
        "automation", "saas", "data storage", "dashboard",
    },
    "Entertainment": {
        "movies", "music", "streaming", "watch online", "games", "gaming",
        "entertainment", "episodes", "shows", "videos",
    },
    "Portfolio or agency": {
        "portfolio", "our work", "case studies", "creative agency", "designer",
        "developer portfolio", "services", "contact us",
    },
}

LAYOUT_WORDS = {
    "header", "hero", "nav", "navbar", "menu", "sidebar", "footer", "banner",
    "card", "cards", "grid", "flex", "column", "row", "modal", "carousel",
    "gallery", "container", "section", "content", "search", "form", "button",
}

COLOR_PATTERN = re.compile(
    r"#[0-9a-f]{3,8}\b|rgba?\([^)]{3,60}\)|hsla?\([^)]{3,60}\)", re.I
)
FONT_PATTERN = re.compile(r"font-family\s*:\s*([^;}]+)", re.I)
TOKEN_PATTERN = re.compile(r"[a-z][a-z0-9'-]{1,40}", re.I)
DYNAMIC_VALUE_PATTERN = re.compile(
    r"\b(?:[0-9a-f]{8}-[0-9a-f-]{27,}|[0-9]{5,}|[0-9a-f]{20,})\b", re.I
)


class URLValidationError(ValueError):
    """The supplied URL is not safe or valid for a server-side fetch."""


class WebsiteFetchError(RuntimeError):
    """The public website could not be downloaded or analyzed."""


def normalize_url(raw_url):
    value = str(raw_url or "").strip()
    if not value:
        raise URLValidationError("Both website URLs are required")
    if len(value) > 2048:
        raise URLValidationError("A website URL is too long")

    parsed = urlsplit(value)
    if parsed.scheme.lower() not in {"http", "https"}:
        raise URLValidationError("Website URLs must begin with http:// or https://")
    if not parsed.hostname:
        raise URLValidationError("A website URL has no valid hostname")
    if parsed.username or parsed.password:
        raise URLValidationError("Website URLs cannot contain credentials")

    try:
        port = parsed.port
    except ValueError as error:
        raise URLValidationError("A website URL contains an invalid port") from error

    allowed_port = 443 if parsed.scheme.lower() == "https" else 80
    if port not in {None, allowed_port}:
        raise URLValidationError("Only standard HTTP and HTTPS ports are allowed")

    hostname = parsed.hostname.rstrip(".").lower()
    if hostname == "localhost" or hostname.endswith(".local"):
        raise URLValidationError("Local or private website addresses are not allowed")

    try:
        address_info = socket.getaddrinfo(hostname, port or allowed_port, type=socket.SOCK_STREAM)
    except socket.gaierror as error:
        raise URLValidationError(f"Could not resolve the hostname {hostname}") from error

    for address in {entry[4][0] for entry in address_info}:
        try:
            if not ipaddress.ip_address(address).is_global:
                raise URLValidationError("Local or private website addresses are not allowed")
        except ValueError as error:
            raise URLValidationError("A website hostname resolved to an invalid address") from error

    clean_netloc = hostname
    if port:
        clean_netloc = f"{hostname}:{port}"

    return urlunsplit((parsed.scheme.lower(), clean_netloc, parsed.path or "/", parsed.query, ""))


class SafeRedirectHandler(HTTPRedirectHandler):
    def redirect_request(self, request, file_pointer, code, message, headers, new_url):
        safe_url = normalize_url(urljoin(request.full_url, new_url))
        return super().redirect_request(
            request, file_pointer, code, message, headers, safe_url
        )


def fetch_website(raw_url):
    safe_url = normalize_url(raw_url)
    request = Request(
        safe_url,
        headers={
            "User-Agent": USER_AGENT,
            "Accept": "text/html,application/xhtml+xml;q=0.9,*/*;q=0.1",
            "Accept-Language": "en-US,en;q=0.8",
        },
    )

    try:
        with build_opener(SafeRedirectHandler()).open(
            request, timeout=FETCH_TIMEOUT_SECONDS
        ) as response:
            final_url = normalize_url(response.geturl())
            content_type = response.headers.get_content_type()
            charset = response.headers.get_content_charset() or "utf-8"
            payload = response.read(MAX_RESPONSE_BYTES + 1)
    except HTTPError as error:
        raise WebsiteFetchError(
            f"{urlsplit(safe_url).hostname} returned HTTP {error.code}"
        ) from error
    except (URLError, TimeoutError, socket.timeout) as error:
        reason = getattr(error, "reason", error)
        raise WebsiteFetchError(
            f"Could not reach {urlsplit(safe_url).hostname}: {reason}"
        ) from error

    if len(payload) > MAX_RESPONSE_BYTES:
        raise WebsiteFetchError("A website response is too large to analyze safely")

    try:
        html = payload.decode(charset, errors="replace")
    except LookupError:
        html = payload.decode("utf-8", errors="replace")

    if content_type not in {"text/html", "application/xhtml+xml"} and "<html" not in html[:1000].lower():
        raise WebsiteFetchError("A supplied URL did not return an HTML webpage")

    return {
        "requestedUrl": safe_url,
        "finalUrl": final_url,
        "html": html,
    }


class WebsiteHTMLParser(HTMLParser):
    SKIP_TEXT_TAGS = {"script", "noscript", "svg", "template"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.visible_parts = []
        self.title_parts = []
        self.description = ""
        self.tags = []
        self.class_tokens = []
        self.style_parts = []
        self.heading_parts = []
        self._skip_depth = 0
        self._style_depth = 0
        self._title_depth = 0
        self._heading_depth = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        attrs_map = {str(key).lower(): str(value or "") for key, value in attrs}

        if len(self.tags) < MAX_STRUCTURE_TAGS:
            self.tags.append(tag)

        for attr_name in ("class", "id", "role"):
            self.class_tokens.extend(tokenize_attribute(attrs_map.get(attr_name, "")))

        inline_style = attrs_map.get("style")
        if inline_style:
            self.style_parts.append(inline_style)

        if tag == "meta":
            meta_name = attrs_map.get("name", "").lower()
            meta_property = attrs_map.get("property", "").lower()
            if meta_name == "description" or meta_property == "og:description":
                self.description = self.description or attrs_map.get("content", "").strip()

        if tag in self.SKIP_TEXT_TAGS:
            self._skip_depth += 1
        elif tag == "style":
            self._style_depth += 1
        elif tag == "title":
            self._title_depth += 1
        elif tag in {"h1", "h2", "h3"}:
            self._heading_depth += 1

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag in self.SKIP_TEXT_TAGS and self._skip_depth:
            self._skip_depth -= 1
        elif tag == "style" and self._style_depth:
            self._style_depth -= 1
        elif tag == "title" and self._title_depth:
            self._title_depth -= 1
        elif tag in {"h1", "h2", "h3"} and self._heading_depth:
            self._heading_depth -= 1

    def handle_data(self, data):
        clean = collapse_space(data)
        if not clean:
            return
        if self._style_depth:
            self.style_parts.append(clean)
            return
        if self._skip_depth:
            return
        if self._title_depth:
            self.title_parts.append(clean)
        if self._heading_depth:
            self.heading_parts.append(clean)
        self.visible_parts.append(clean)


def collapse_space(value):
    return re.sub(r"\s+", " ", str(value or "")).strip()


def tokenize_attribute(value):
    return [
        token.lower()
        for token in re.split(r"[^a-zA-Z0-9_-]+", value)
        if 1 < len(token) < 50
    ]


def text_tokens(value):
    return [
        token.lower()
        for token in TOKEN_PATTERN.findall(value or "")
        if token.lower() not in STOP_WORDS
    ][:MAX_TEXT_WORDS]


def shingles(tokens, width=3):
    if len(tokens) < width:
        return set(tokens)
    return {" ".join(tokens[index:index + width]) for index in range(len(tokens) - width + 1)}


def jaccard(left, right):
    left = set(left)
    right = set(right)
    if not left and not right:
        return 0.0
    return len(left & right) / max(1, len(left | right))


def percent(value):
    return round(max(0.0, min(100.0, value)), 1)


def detect_category(searchable_text):
    lowered = searchable_text.lower()
    scores = {}
    matches = {}

    for category, keywords in CATEGORY_KEYWORDS.items():
        matched = {keyword for keyword in keywords if keyword in lowered}
        scores[category] = sum(2 if " " in keyword else 1 for keyword in matched)
        matches[category] = matched

    best_category = max(scores, key=scores.get)
    if scores[best_category] < 2:
        return "Unclassified", set()
    return best_category, matches[best_category]


def analyze_document(download):
    parser = WebsiteHTMLParser()
    try:
        parser.feed(download["html"])
    except Exception as error:
        raise WebsiteFetchError("A website returned malformed HTML that could not be analyzed") from error

    title = collapse_space(" ".join(parser.title_parts))
    visible_text = collapse_space(" ".join(parser.visible_parts))
    description = collapse_space(parser.description)
    headings = collapse_space(" ".join(parser.heading_parts))
    searchable = collapse_space(" ".join([title, description, headings, visible_text]))
    tokens = text_tokens(searchable)
    category, category_matches = detect_category(searchable)

    style_text = " ".join(parser.style_parts).lower()
    colors = {match.lower().replace(" ", "") for match in COLOR_PATTERN.findall(style_text)}
    fonts = {
        collapse_space(match).lower().strip("'\"")
        for match in FONT_PATTERN.findall(style_text)
        if collapse_space(match)
    }
    class_tokens = {token.lower() for token in parser.class_tokens}
    layout_tokens = {
        layout_word
        for layout_word in LAYOUT_WORDS
        if layout_word in class_tokens or re.search(rf"\b{re.escape(layout_word)}\b", style_text)
    }

    return {
        "url": download["requestedUrl"],
        "finalUrl": download["finalUrl"],
        "host": urlsplit(download["finalUrl"]).hostname or "",
        "title": title[:200],
        "description": description[:350],
        "tokens": tokens,
        "topTerms": {term for term, _ in Counter(tokens).most_common(50)},
        "tags": parser.tags,
        "classTokens": class_tokens,
        "colors": colors,
        "fonts": fonts,
        "layoutTokens": layout_tokens,
        "category": category,
        "categoryMatches": category_matches,
        "sampleWords": len(tokens),
        "htmlBytes": len(download["html"].encode("utf-8", errors="ignore")),
    }


def concept_similarity(left, right):
    term_overlap = jaccard(left["topTerms"], right["topTerms"])
    same_known_category = (
        left["category"] != "Unclassified"
        and left["category"] == right["category"]
    )
    if same_known_category:
        return percent(78 + (term_overlap * 22))
    if left["category"] != "Unclassified" and right["category"] != "Unclassified":
        return percent(min(45, term_overlap * 100))
    return percent(term_overlap * 100)


def content_similarity(left, right):
    return percent(jaccard(shingles(left["tokens"]), shingles(right["tokens"])) * 100)


def code_similarity(left, right):
    left_tags = " ".join(left["tags"])
    right_tags = " ".join(right["tags"])
    sequence_score = SequenceMatcher(None, left_tags, right_tags, autojunk=True).ratio()
    class_score = jaccard(left["classTokens"], right["classTokens"])
    return percent(((sequence_score * 0.72) + (class_score * 0.28)) * 100)


def visual_similarity(left, right):
    color_score = jaccard(left["colors"], right["colors"])
    font_score = jaccard(left["fonts"], right["fonts"])
    layout_score = jaccard(left["layoutTokens"], right["layoutTokens"])

    available_weights = []
    if left["colors"] or right["colors"]:
        available_weights.append((color_score, 0.40))
    if left["fonts"] or right["fonts"]:
        available_weights.append((font_score, 0.20))
    if left["layoutTokens"] or right["layoutTokens"]:
        available_weights.append((layout_score, 0.40))

    if not available_weights:
        return 0.0

    total_weight = sum(weight for _, weight in available_weights)
    return percent(sum(score * weight for score, weight in available_weights) / total_weight * 100)


def build_verdict(scores):
    duplication = scores["duplication"]
    concept = scores["concept"]

    if duplication >= 78:
        return {
            "level": "duplicate",
            "label": "High duplication risk",
            "title": "Likely duplicate or cloned website",
            "explanation": (
                "The websites share unusually strong content, code-structure, and design signals. "
                "Review the matching evidence before making any legal or ownership conclusion."
            ),
        }
    if duplication >= 50:
        return {
            "level": "possible",
            "label": "Manual review recommended",
            "title": "Possible website duplication",
            "explanation": (
                "Several implementation signals overlap, but the automated evidence is not "
                "strong enough to call the websites duplicates without human review."
            ),
        }
    if concept >= 65:
        return {
            "level": "related",
            "label": "Related concept",
            "title": "Same category — not a duplicate",
            "explanation": (
                "The websites appear to solve a similar problem, but their content, code, and "
                "design do not show enough overlap to indicate duplication."
            ),
        }
    return {
        "level": "different",
        "label": "Low duplication risk",
        "title": "Different websites",
        "explanation": (
            "The websites do not share enough implementation evidence to be considered duplicates."
        ),
    }


def public_summary(document):
    return {
        "url": document["url"],
        "finalUrl": document["finalUrl"],
        "host": document["host"],
        "title": document["title"] or document["host"],
        "description": document["description"],
        "category": document["category"],
        "sampleWords": document["sampleWords"],
        "htmlBytes": document["htmlBytes"],
    }


def build_evidence(left, right, scores):
    if left["category"] == right["category"] and left["category"] != "Unclassified":
        category_text = f"Both websites were classified as {left['category']}."
    else:
        category_text = (
            f"Business categories: {left['category']} and {right['category']}."
        )

    evidence = [
        category_text,
        f"Visible content overlap measured {scores['content']}% using matching word sequences.",
        f"HTML structure and reusable class-pattern overlap measured {scores['code']}%.",
        f"Available colour, font, and layout markers overlapped by {scores['visual']}%.",
        "The duplication score excludes concept similarity to avoid flagging legitimate competitors.",
    ]
    return evidence


def compare_websites(url_a, url_b):
    left = analyze_document(fetch_website(url_a))
    right = analyze_document(fetch_website(url_b))

    scores = {
        "concept": concept_similarity(left, right),
        "content": content_similarity(left, right),
        "code": code_similarity(left, right),
        "visual": visual_similarity(left, right),
    }
    scores["duplication"] = percent(
        (scores["content"] * 0.45)
        + (scores["code"] * 0.35)
        + (scores["visual"] * 0.20)
    )

    warnings = []
    if left["sampleWords"] < 80:
        warnings.append(f"{left['host']} exposed limited readable text, so its content score is less reliable.")
    if right["sampleWords"] < 80:
        warnings.append(f"{right['host']} exposed limited readable text, so its content score is less reliable.")
    if not (left["colors"] or right["colors"] or left["layoutTokens"] or right["layoutTokens"]):
        warnings.append("Little inline design information was available; external stylesheets are not downloaded in this safe scan.")
    if left["finalUrl"] == right["finalUrl"]:
        warnings.append("Both inputs resolved to the same final URL.")

    return {
        "scores": scores,
        "verdict": build_verdict(scores),
        "websites": {
            "a": public_summary(left),
            "b": public_summary(right),
        },
        "evidence": build_evidence(left, right, scores),
        "warnings": warnings,
        "method": {
            "version": "1.0",
            "duplicationWeights": {
                "content": 0.45,
                "code": 0.35,
                "visual": 0.20,
                "concept": 0.0,
            },
            "note": "Concept similarity is reported separately and is not proof of duplication.",
        },
    }


def response(status_code, payload):
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "content-type",
            "Access-Control-Allow-Methods": "POST,OPTIONS",
        },
        "body": json.dumps(payload),
    }


def lambda_handler(event, context):
    method = (
        event.get("requestContext", {}).get("http", {}).get("method")
        or event.get("httpMethod")
        or "POST"
    ).upper()

    if method == "OPTIONS":
        return response(204, {})

    try:
        body = event.get("body", event)
        if isinstance(body, str):
            body = json.loads(body or "{}")
        if not isinstance(body, dict):
            raise URLValidationError("Request body must be a JSON object")

        result = compare_websites(body.get("urlA"), body.get("urlB"))
        return response(200, result)
    except (URLValidationError, json.JSONDecodeError) as error:
        return response(400, {"message": str(error) or "Invalid request"})
    except WebsiteFetchError as error:
        return response(422, {"message": str(error)})
    except Exception as error:
        print(f"Unexpected website comparison error: {error}")
        return response(500, {"message": "Website comparison failed unexpectedly"})
