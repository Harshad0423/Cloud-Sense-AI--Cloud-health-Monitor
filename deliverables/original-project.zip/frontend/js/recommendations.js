/**
 * recommendations.js
 * Renders the Recommendations page and handles "Take Action" flows.
 */

let allRecommendations = [];

document.addEventListener("DOMContentLoaded", async () => {
  renderShell("recommendations");
  try {
    allRecommendations = await api.getRecommendations();
  } catch (error) {
    allRecommendations = [];
    toast(`Could not load recommendations: ${error.message}`, "error", 6000);
  }

  document.getElementById("priorityFilter").addEventListener("change", renderRecommendations);
  renderRecommendations();
});

function renderRecommendations() {
  const filter = document.getElementById("priorityFilter").value;
  const grid = document.getElementById("recGrid");
  const emptyState = document.getElementById("recEmptyState");

  const items = filter === "all" ? allRecommendations : allRecommendations.filter((r) => r.priority === filter);

  if (items.length === 0) {
    grid.innerHTML = "";
    emptyState.innerHTML = emptyRecommendationsHTML();
  } else {
    emptyState.innerHTML = "";
    grid.innerHTML = items.map(recCardHTML).join("");
  }

  wireActionButtons();
}

function wireActionButtons() {
  document.querySelectorAll(".rec-action-btn").forEach((btn) => {
    btn.addEventListener("click", () => handleTakeAction(btn.dataset.recId, btn.dataset.action));
  });
}

async function handleTakeAction(recId, actionType) {
  const rec = allRecommendations.find((r) => String(r.id) === String(recId));
  if (!rec) return;

  if (actionType === "review-file") {
    window.location.href = `files.html?q=${encodeURIComponent(rec.fileName)}`;
    return;
  }

  if (actionType !== "delete-duplicate") return;

  const confirmed = await confirmDialog({
    title: "Delete duplicate?",
    message: `Permanently delete <strong>${rec.fileName}</strong>? This will recover ${rec.saving}.`,
    confirmLabel: "Delete duplicate",
    danger: true,
  });
  if (!confirmed) return;

  try {
    await api.deleteFile(rec.fileId);
    allRecommendations = allRecommendations.filter((r) => String(r.id) !== String(recId));
    renderRecommendations();
    toast(`${rec.fileName} deleted successfully`, "success");
  } catch (error) {
    toast(`Could not delete ${rec.fileName}: ${error.message}`, "error", 6000);
  }
}
