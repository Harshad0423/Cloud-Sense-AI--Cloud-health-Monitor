/**
 * dashboard.js
 * Renders the Dashboard page using data from api.* (see app.js).
 */

document.addEventListener("DOMContentLoaded", async () => {
  renderShell("dashboard");

  const [dashboard, recommendations] = await Promise.all([
    api.getDashboardStats(),
    api.getRecommendations(),
  ]);
  const { health, storage } = dashboard;
  const summary = {
    ...dashboard.summary,
    healthScore: health.score,
    healthLabel: health.label,
    healthSubtitle: health.subtitle,
    storageUsed: storage.formattedUsed,
    storageUsedBytes: storage.usedBytes,
    storageTotalGB: storage.totalGB,
  };

  renderMetricGrid(summary);
  renderHealthCard(health);
  renderStorageUsed(storage);
  renderRecPreview(recommendations.slice(0, 3));
});

function renderMetricGrid(summary) {
  const grid = document.getElementById("metricGrid");

  const cards = [
    {
      label: "Cloud Health Score",
      value: `${summary.healthScore}/100`,
      note: `${summary.healthLabel} — ${summary.healthSubtitle}`,
      icon: "cloud", iconClass: "icon-bg-teal",
    },
    {
      label: "Storage Used",
      value: summary.storageUsed,
      note: `of ${summary.storageTotalGB} GB`,
      icon: "folder", iconClass: "icon-bg-blue",
      progress: Math.min((storageBytesToGB(summary.storageUsedBytes) / summary.storageTotalGB) * 100, 100),
    },
    {
      label: "Duplicate Files",
      value: summary.duplicates,
      note: "Files consuming unnecessary space",
      icon: "close", iconClass: "icon-bg-red",
    },
    {
      label: "Inactive Files",
      value: summary.inactive,
      note: "Files not accessed recently",
      icon: "gear", iconClass: "icon-bg-amber",
    },
    {
      label: "Large Files",
      value: summary.large,
      note: "Files requiring optimization",
      icon: "chart", iconClass: "icon-bg-violet",
    },
    {
      label: "Potential Savings",
      value: summary.potentialSavings,
      note: "Storage recoverable through cleanup",
      icon: "bulb", iconClass: "icon-bg-teal",
    },
  ];

  grid.innerHTML = cards.map((c) => `
    <div class="card metric-card">
      <div class="metric-top">
        <span class="metric-label">${c.label}</span>
        <span class="metric-icon ${c.iconClass}">${ICONS[c.icon]}</span>
      </div>
      <span class="metric-value">${c.value}</span>
      ${c.progress !== undefined ? `
        <div class="progress-track"><div class="progress-fill" style="width:${c.progress}%"></div></div>
      ` : ""}
      <span class="metric-note">${c.note}</span>
    </div>
  `).join("");
}

function renderHealthCard(health) {
  const card = document.getElementById("healthCard");
  card.innerHTML = `
    <div class="health-ring-wrap">
      <div class="health-ring-ticks"></div>
      <div class="health-ring" style="--score:${health.score}">
        <div class="health-ring-value">
          <span class="score">${health.score}</span>
          <span class="max">/ ${health.max}</span>
        </div>
      </div>
    </div>
    <div class="health-info">
      <span class="health-badge">${health.label}</span>
      <h3>Cloud Health Score</h3>
      <p class="desc">${health.subtitle}</p>
      <a href="analytics.html" class="link-btn">How is this calculated? →</a>
    </div>
  `;
}

function storageBytesToGB(bytes) {
  return Number(bytes || 0) / (1024 ** 3);
}

function renderStorageUsed(storage) {
  const block = document.getElementById("storageUsedBlock");
  const total = storage.totalGB || 15;
  const usedGB = storageBytesToGB(storage.usedBytes);
  const pct = Math.min((usedGB / total) * 100, 100);
  const largestCategory = Math.max(...storage.breakdown.map((b) => Number(b.bytes || 0)), 1);

  block.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:8px;">
      <span class="metric-value" style="font-size:22px;">${storage.formattedUsed} <span class="text-muted" style="font-size:13px;font-weight:500;">of ${total} GB</span></span>
      <span class="mono" style="font-size:13px;color:var(--text-600);">${pct.toFixed(2)}% used</span>
    </div>
    <div class="progress-track" style="height:10px;margin-bottom:18px;">
      <div class="progress-fill" style="width:${pct}%"></div>
    </div>
    <div class="bar-chart-list">
      ${storage.breakdown.map((b) => `
        <div class="bar-chart-row">
          <span class="bar-chart-label">${b.category}</span>
          <div class="bar-chart-track">
            <div class="bar-chart-fill" style="width:${(Number(b.bytes || 0) / largestCategory) * 100}%; background:${b.color}"></div>
          </div>
          <span class="bar-chart-value">${b.formattedSize}</span>
        </div>
      `).join("")}
    </div>
  `;
}

function renderRecPreview(recs) {
  const grid = document.getElementById("dashboardRecPreview");
  if (!recs.length) {
    grid.innerHTML = emptyRecommendationsHTML();
    return;
  }
  grid.innerHTML = recs.map(recCardHTML).join("");
}
