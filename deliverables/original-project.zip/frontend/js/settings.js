/**
 * settings.js
 * Loads and saves settings through the CloudSense AWS API.
 */

document.addEventListener("DOMContentLoaded", async () => {
  renderShell("settings");
  wireFrequencyGroup();
  document.getElementById("saveSettingsBtn").addEventListener("click", handleSave);

  try {
    const settings = await api.getSettings();
    populateForm(settings);
    updateShellUser(settings.account.name);
  } catch (error) {
    console.error(error);
    populateForm(mockSettings);
    toast(error.message || "Could not load settings", "error");
  }
});

function updateShellUser(name) {
  const safeName = name || "CloudSense User";
  const nameElement = document.querySelector(".user-name");
  const avatarElement = document.querySelector(".avatar");

  if (nameElement) nameElement.textContent = safeName;
  if (avatarElement) {
    avatarElement.textContent = safeName
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((part) => part[0].toUpperCase())
      .join("") || "CU";
  }
}

function populateForm(settings) {
  document.getElementById("accountName").value = settings.account.name;
  document.getElementById("accountEmail").value = settings.account.email;

  document.querySelectorAll(".radio-option").forEach((el) => {
    el.classList.toggle("selected", el.dataset.value === settings.analysisFrequency);
  });

  document.getElementById("notifEmailReports").checked = settings.notifications.emailReports;
  document.getElementById("notifDuplicateAlerts").checked = settings.notifications.duplicateAlerts;
  document.getElementById("notifStorageWarnings").checked = settings.notifications.storageWarnings;
}

function wireFrequencyGroup() {
  document.querySelectorAll(".radio-option").forEach((el) => {
    el.addEventListener("click", () => {
      document.querySelectorAll(".radio-option").forEach((o) => o.classList.remove("selected"));
      el.classList.add("selected");
    });
  });
}

async function handleSave() {
  const selectedFrequency = document.querySelector(".radio-option.selected")?.dataset.value || "weekly";

  const updatedSettings = {
    account: {
      name: document.getElementById("accountName").value.trim(),
      email: document.getElementById("accountEmail").value.trim(),
    },
    analysisFrequency: selectedFrequency,
    notifications: {
      emailReports: document.getElementById("notifEmailReports").checked,
      duplicateAlerts: document.getElementById("notifDuplicateAlerts").checked,
      storageWarnings: document.getElementById("notifStorageWarnings").checked,
    },
  };

  const btn = document.getElementById("saveSettingsBtn");
  btn.disabled = true;
  btn.textContent = "Saving…";

  try {
    await api.saveSettings(updatedSettings);
    updateShellUser(updatedSettings.account.name);
    toast("Settings saved to AWS", "success");
  } catch (error) {
    console.error(error);
    toast(error.message || "Could not save settings", "error");
  } finally {
    btn.disabled = false;
    btn.textContent = "Save Changes";
  }
}
