/**
 * mockData.js
 * ------------------------------------------------------------------
 * CURRENT STATE (Layer 1 — frontend only):
 *   All data below is hand-written mock data. Nothing here comes
 *   from a network call.
 *
 * FUTURE STATE (Layer 2 — AWS connected):
 *   This file will be deleted. The functions in js/app.js that
 *   currently `return mockX` will instead `fetch()` the same shape
 *   of data from API Gateway → Lambda → DynamoDB / S3.
 *
 * Keeping the shape realistic now means the UI code in
 * dashboard.js / files.js / recommendations.js will not need to
 * change later — only the data source changes.
 * ------------------------------------------------------------------
 */

// ---------------------------------------------------------------
// FILES
// ---------------------------------------------------------------
const mockFiles = [
  { id: 1,  name: "Assignment.pdf",        sizeMB: 2,     type: "PDF",    uploaded: "Today",         lastAccessed: "Today",        status: "Healthy" },
  { id: 2,  name: "Assignment_Copy.pdf",   sizeMB: 2,     type: "PDF",    uploaded: "Today",         lastAccessed: "Today",        status: "Duplicate", duplicateOf: 1 },
  { id: 3,  name: "Project.zip",           sizeMB: 3200,  type: "ZIP",    uploaded: "2 months ago",  lastAccessed: "90 days ago",  status: "Inactive" },
  { id: 4,  name: "Movie.mp4",             sizeMB: 1500,  type: "MP4",    uploaded: "1 month ago",   lastAccessed: "60 days ago",  status: "Large" },
  { id: 5,  name: "Resume.pdf",            sizeMB: 1.1,   type: "PDF",    uploaded: "3 months ago",  lastAccessed: "5 days ago",   status: "Healthy" },
  { id: 6,  name: "Resume_Copy.pdf",       sizeMB: 1.1,   type: "PDF",    uploaded: "3 months ago",  lastAccessed: "5 days ago",   status: "Duplicate", duplicateOf: 5 },
  { id: 7,  name: "Vacation_Photos.zip",   sizeMB: 850,   type: "ZIP",    uploaded: "6 months ago",  lastAccessed: "120 days ago", status: "Inactive" },
  { id: 8,  name: "Lecture_Notes.docx",    sizeMB: 4.4,   type: "DOCX",   uploaded: "1 week ago",    lastAccessed: "Yesterday",    status: "Healthy" },
  { id: 9,  name: "Backup_2023.zip",       sizeMB: 4800,  type: "ZIP",    uploaded: "1 year ago",    lastAccessed: "300 days ago", status: "Large" },
  { id: 10, name: "Product_Demo.mp4",      sizeMB: 980,   type: "MP4",    uploaded: "2 weeks ago",   lastAccessed: "2 weeks ago",  status: "Healthy" },
  { id: 11, name: "Invoice_March.pdf",     sizeMB: 0.6,   type: "PDF",    uploaded: "5 months ago",  lastAccessed: "5 months ago", status: "Inactive" },
  { id: 12, name: "Team_Photo.jpg",        sizeMB: 6.2,   type: "JPG",    uploaded: "3 weeks ago",   lastAccessed: "3 weeks ago",  status: "Healthy" },
];

// ---------------------------------------------------------------
// HEALTH SCORE
// ---------------------------------------------------------------
const mockHealthScore = {
  score: 82,
  max: 100,
  label: "Good",
  subtitle: "Storage can still be optimized",
  breakdown: [
    { label: "Duplicate files",   penalty: -6,  detail: "3 duplicate files x -2 avg" },
    { label: "Inactive files",    penalty: -12, detail: "4 inactive files x -3 avg" },
    { label: "Large files",       penalty: -4,  detail: "2 large files x -2 avg" },
    { label: "Storage usage",     penalty: 0,   detail: "Normal", isNeutral: true },
  ],
  scoringRules: [
    { label: "Starting score",        value: "100" },
    { label: "Duplicate files",       value: "-5 each" },
    { label: "Large unused files",    value: "-10 each" },
    { label: "Empty folders",         value: "-3 each" },
    { label: "Inactive files",        value: "-15 each" },
    { label: "Final score",           value: "82", isFinal: true },
  ],
  trend: [
    { day: "Day 1", score: 91 },
    { day: "Day 2", score: 88 },
    { day: "Day 3", score: 86 },
    { day: "Day 4", score: 82 },
    { day: "Day 5", score: 82 },
    { day: "Day 6", score: 84 },
    { day: "Day 7", score: 82 },
  ],
};

// ---------------------------------------------------------------
// STORAGE STATISTICS
// ---------------------------------------------------------------
const mockStorageStats = {
  usedGB: 8.5,
  totalGB: 15,
  breakdown: [
    { category: "Documents", gb: 1.8, color: "#2F6FED" },
    { category: "Videos",    gb: 3.9, color: "#17B8A6" },
    { category: "Images",    gb: 1.1, color: "#F5A623" },
    { category: "Archives",  gb: 1.4, color: "#8A5CF6" },
    { category: "Other",     gb: 0.3, color: "#8A93A6" },
  ],
};

// ---------------------------------------------------------------
// RECOMMENDATIONS
// ---------------------------------------------------------------
const mockRecommendations = [
  {
    id: 1,
    priority: "high",
    priorityLabel: "HIGH PRIORITY",
    fileName: "Resume_Copy.pdf",
    problem: "Duplicate file",
    recommendation: "Delete this duplicate",
    savingLabel: "Potential saving",
    saving: "2 MB",
    actionLabel: "Take Action",
    actionType: "delete",
  },
  {
    id: 2,
    priority: "high",
    priorityLabel: "HIGH PRIORITY",
    fileName: "Assignment_Copy.pdf",
    problem: "Duplicate file",
    recommendation: "Delete this duplicate",
    savingLabel: "Potential saving",
    saving: "2 MB",
    actionLabel: "Take Action",
    actionType: "delete",
  },
  {
    id: 3,
    priority: "medium",
    priorityLabel: "OPTIMIZATION",
    fileName: "Project.zip",
    problem: "Inactive for 90 days",
    recommendation: "Move to Amazon S3 Glacier",
    savingLabel: "Estimated saving",
    saving: "₹70/month",
    actionLabel: "View Details",
    actionType: "archive",
  },
  {
    id: 4,
    priority: "medium",
    priorityLabel: "OPTIMIZATION",
    fileName: "Vacation_Photos.zip",
    problem: "Inactive for 120 days",
    recommendation: "Move to Amazon S3 Glacier",
    savingLabel: "Estimated saving",
    saving: "₹42/month",
    actionLabel: "View Details",
    actionType: "archive",
  },
  {
    id: 5,
    priority: "low",
    priorityLabel: "STORAGE OPTIMIZATION",
    fileName: "Movie.mp4",
    problem: "Large file",
    recommendation: "Compress file",
    savingLabel: "Estimated space saved",
    saving: "500 MB",
    actionLabel: "Optimize",
    actionType: "compress",
  },
  {
    id: 6,
    priority: "low",
    priorityLabel: "STORAGE OPTIMIZATION",
    fileName: "Backup_2023.zip",
    problem: "Large file, rarely accessed",
    recommendation: "Move to Amazon S3 Glacier",
    savingLabel: "Estimated saving",
    saving: "₹110/month",
    actionLabel: "View Details",
    actionType: "archive",
  },
];

// ---------------------------------------------------------------
// NOTIFICATIONS
// ---------------------------------------------------------------
const mockNotifications = [
  { id: 1, icon: "warning",  text: "6 duplicate files detected",            time: "2h ago"  },
  { id: 2, icon: "insight",  text: "You can save approximately ₹250/month", time: "2h ago"  },
  { id: 3, icon: "report",   text: "Weekly storage analysis completed",     time: "1d ago"  },
  { id: 4, icon: "success",  text: "File upload completed",                 time: "2d ago"  },
];

// ---------------------------------------------------------------
// SETTINGS
// ---------------------------------------------------------------
const mockSettings = {
  account: { name: "Aarav Sharma", email: "aarav.sharma@example.com" },
  analysisFrequency: "weekly",
  notifications: { emailReports: true, duplicateAlerts: true, storageWarnings: true },
};

// ---------------------------------------------------------------
// SUMMARY (used on Dashboard cards + Reports page)
// ---------------------------------------------------------------
function getDashboardSummary() {
  const duplicates = mockFiles.filter((f) => f.status === "Duplicate").length;
  const inactive = mockFiles.filter((f) => f.status === "Inactive").length;
  const large = mockFiles.filter((f) => f.status === "Large").length;
  return {
    healthScore: mockHealthScore.score,
    healthLabel: mockHealthScore.label,
    healthSubtitle: mockHealthScore.subtitle,
    storageUsedGB: mockStorageStats.usedGB,
    storageTotalGB: mockStorageStats.totalGB,
    duplicates,
    inactive,
    large,
    potentialSavings: "₹250/month",
  };
}
